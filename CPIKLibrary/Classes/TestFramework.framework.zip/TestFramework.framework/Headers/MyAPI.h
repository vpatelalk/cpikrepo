#import <Foundation/Foundation.h>

@interface MyAPI : NSObject
@property(nonatomic) long sequence;
-(long) getNumber;
+(long) getSequence;
@end
